#!/usr/bin/perl

#
# Authentic Theme 17.84 (https://github.com/qooob/authentic-theme)
# Copyright 2015 Alexandr Bezenkov (https://github.com/Real-Gecko/filemin)
# Copyright 2016 Ilia Rostovtsev <programming@rostovtsev.ru>
# Licensed under MIT (https://github.com/qooob/authentic-theme/blob/master/LICENSE)
#

use File::Basename;
require (dirname(__FILE__) . '/file-manager-lib.pm');

open( my $fh, "<" . &get_paste_buffer_file() ) or die "Error: $!";
my @arr = <$fh>;
close($fh);
my $act = $arr[0];
my $dir = $arr[1];
chomp($act);
chomp($dir);
$from = abs_path( $base . $dir );
my @errors;
my $mv = ( $act eq "copy"            ? 0 : 1 );
my $fr = ( length $request_uri{'ua'} ? 1 : 0 );
my $fo = ( $request_uri{'ua'} eq '1' ? 1 : 0 );

for ( my $i = 2; $i <= scalar(@arr) - 1; $i++ ) {
    chomp( $arr[$i] );

    if ( ( -e "$cwd/$arr[$i]" ) && $cwd ne $from && !$fr ) {
        set_response('ep');
    }
    else {
        $out = paster( "$cwd", "$arr[$i]", "$from/$arr[$i]", "$cwd/$arr[$i]", $fo, $mv );
    }
    $out && push( @errors, $out );
}

if ( scalar(@errors) > 0 ) {
    set_response('err');
    print_errors(@errors);
}
else {
    set_response_count( scalar(@arr) - 2 );
    &redirect( '/' . $request_uri{'module'} . '/index.cgi?path=' . $path );
}
